This directory will be the home for internationalizations for your theme 
package.  For more information on internationalization please consult the 
following sources:

http://plone.org/documentation/kb/product-skin-localization
http://plone.org/documentation/kb/i18n-for-developers
http://www.mattdorn.com/content/plone-i18n-a-brief-tutorial/
http://grok.zope.org/documentation/how-to/how-to-internationalize-your-application
http://maurits.vanrees.org/weblog/archive/2010/10/i18n-plone-4
http://maurits.vanrees.org/weblog/archive/2007/09/i18n-locales-and-plone-3.0
http://n2.nabble.com/Recipe-for-overriding-translations-td3045492ef221724.html
http://dev.plone.org/plone/wiki/TranslationGuidelines
