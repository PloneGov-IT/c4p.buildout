# -*- coding: utf-8 -*-

from zope.interface import implements
from zope.component import getMultiAdapter
from zope import schema
from zope.formlib import form

from plone.app.portlets.portlets.login import ILoginPortlet
from plone.app.portlets.portlets import base

from Products.CMFCore.utils import getToolByName
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile

from cciaa.portlet.login import PortletLoginMessageFactory as _


class IPortletLogin(ILoginPortlet):
    """A portlet

    It inherits from ILoginPortlet"""

    header = schema.TextLine(title=_(u"Label"),
                             required=True)
    field1_text = schema.TextLine(title=_(u"Campo 1"),
                                  description=_(u"inserisci il testo del primo campo"),
                                  required=False)
    field1_url = schema.TextLine(title=_(u"URL campo 1"),
                                  description=_(u"inserisci l'URL del primo campo"),
                                  required=False)
    field2_text = schema.TextLine(title=_(u"Campo 2"),
                                  description=_(u"inserisci il testo del secondo campo"),
                                  required=False)
    field2_url = schema.TextLine(title=_(u"URL campo 2"),
                                  description=_(u"inserisci l'URL del secondo campo"),
                                  required=False)
    field3_text = schema.TextLine(title=_(u"Campo 3"),
                                  description=_(u"inserisci il testo del terzo campo"),
                                  required=False)
    field3_url = schema.TextLine(title=_(u"URL campo 3"),
                                  description=_(u"inserisci l'URL del terzo campo"),
                                  required=False)
    login_label= schema.TextLine(title=_(u"URL campo login"),
                                  description=_(u"inserisci l'URL del campo di login"),
                                  default=u'Personale camerale',
                                  required=True)


class Assignment(base.Assignment):
    """Portlet assignment.

    This is what is actually managed through the portlets UI and associated
    with columns.
    """

    implements(IPortletLogin)

    login_label = u''
    header = u'Area Riservata'
    

    def __init__(self, field1_text=u"", field1_url=u"", field2_text=u"", field2_url=u"",
                 field3_text=u"", field3_url=u"", login_label=u'', header='Area Riservata'):
        self.field1_text = field1_text
        self.field1_url = field1_url
        self.field2_text = field2_text
        self.field2_url = field2_url
        self.field3_text = field3_text
        self.field3_url = field3_url
        self.login_label = login_label
        self.header = header

    @property
    def title(self):
        """This property is used to give the title of the portlet in the
        "manage portlets" screen.
        """
        return "Portlet di Login: " + self.header


class Renderer(base.Renderer):
    """Portlet renderer.
    """
    def __init__(self, context, request, view, manager, data):
        base.Renderer.__init__(self, context, request, view, manager, data)
        self.context_state = getMultiAdapter((context, request), name=u'plone_context_state')
        self.portal_state = getMultiAdapter((context, request), name=u'plone_portal_state')
        self.pas_info = getMultiAdapter((context, request), name=u'pas_info')

    render = ViewPageTemplateFile('portletlogin.pt')

    @property
    def available(self):
        mtool = getToolByName(self.context, 'portal_membership')
        return mtool.isAnonymousUser()


class AddForm(base.AddForm):
    """Portlet add form.
    """
    form_fields = form.Fields(IPortletLogin)

    def create(self, data):
        return Assignment(**data)


class EditForm(base.EditForm):
    """Portlet edit form.
    """
    form_fields = form.Fields(IPortletLogin)
