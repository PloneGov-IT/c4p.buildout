from setuptools import setup, find_packages
import os

version = '1.2.0'

setup(name='cciaa.portlet.login',
      version=version,
      description="A configurable login portlet for Plone",
      long_description=open("README.txt").read() + "\n" +
                       open(os.path.join("docs", "HISTORY.txt")).read(),
      # Get more strings from http://www.python.org/pypi?%3Aaction=list_classifiers
      classifiers=[
        "Framework :: Plone",
        "Framework :: Plone :: 4.3",
        "Programming Language :: Python",
        "Topic :: Software Development :: Libraries :: Python Modules",
        ],
      keywords='plone login portlet',
      author='RedTurtle Technology',
      author_email='RedTurtle Technology',
      url='https://code.redturtle.it/svn/camera_di_commercio_fe/C3P/cciaa.portlet.login',
      license='GPL',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['cciaa', 'cciaa.portlet'],
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'setuptools',
          # -*- Extra requirements: -*-
      ],
      entry_points="""
      # -*- Entry points: -*-
      [z3c.autoinclude.plugin]
      target = plone
      """,
      )
