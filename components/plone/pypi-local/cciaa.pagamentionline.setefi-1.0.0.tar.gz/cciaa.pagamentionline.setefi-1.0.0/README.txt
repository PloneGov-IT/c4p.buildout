Introduction
============
This product is an add-on for Products.CamComPagamentiOnline and provide all utilities to connect with Setefi bank.

In this product there are the utility called by the tool that call bank's webservice to start a payment process, and also the views to handle success and failure returned from the transaction.