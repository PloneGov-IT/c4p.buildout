# -*- coding: utf-8 -*-
from zope.interface import Interface


class ICCIAAPagamentiOnlineSetefiLayer(Interface):
    """Marker interface for SETEFI layer"""
