# -*- coding: utf-8 -*-
import logging
logger = logging.getLogger("cciaa.pagamentionline.setefi")


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
