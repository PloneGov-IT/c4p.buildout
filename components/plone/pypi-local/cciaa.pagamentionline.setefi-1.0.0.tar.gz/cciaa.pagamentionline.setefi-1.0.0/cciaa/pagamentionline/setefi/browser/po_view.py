# -*- coding: utf-8 -*-
from Products.Five import BrowserView
from Products.CMFCore.utils import getToolByName
from Products.CamComPagamentiOnline.tool import IPagamentoOnlineConnection
from socket import timeout
from urllib import urlencode, socket
from urllib2 import urlopen
from cciaa.pagamentionline.setefi import logger
from zope.component import getMultiAdapter


class CommittedView(BrowserView):
    """
    if everythin is ok, print a redirect url that bank's webservice
    uses to call the real done view
    """

    def __call__(self):
        responsecode = self.request.form.get("responsecode", '')
        if responsecode in ["00", "000"]:
            trackid = self.request.form.get("trackid", '')
            auth = self.request.form.get("auth", '')
            camcom_pagamentionline_tool = getToolByName(self.context, 'camcom_pagamentionline_tool')
            pagamento_brain = camcom_pagamentionline_tool.getPagamentoOnlineByCodeTrans(trackid)
            if not pagamento_brain:
                return "Elemento non trovato"
            pagamento_item = pagamento_brain._unrestrictedGetObject()
            pagamento_item.setEsito("OK")
            pagamento_item.setCodAut(auth)
            pagamento_item.reindexObject()
            camcom_pagamentionline_tool.notify(pagamento_item)
            return "REDIRECT=%s/po_done?trackid=%s" % (self.context.absolute_url(), trackid)


class DoneView(BrowserView):
    """
    Update AT infos and print infos to the user
    """

    def getPagamentoItem(self):
        trackid = self.request.form.get("trackid", '')
        camcom_pagamentionline_tool = getToolByName(self.context, 'camcom_pagamentionline_tool')
        return camcom_pagamentionline_tool.getPagamentoOnlineByCodeTrans(trackid)._unrestrictedGetObject()



class SetefiPOSupportView(BrowserView):
    """ Helper view that send request to the server.
    """

    def generateTransactionUrl(self, tool, item):
        """ An example method """
        params = self.generate_params(item, tool)
        service_url = tool.url_post
        original_timeout = socket.getdefaulttimeout()
        socket.setdefaulttimeout(20)
        try:
            response = urlopen(service_url, urlencode(params))
            socket.setdefaulttimeout(original_timeout)
        except timeout:
            socket.setdefaulttimeout(original_timeout)
            logger.warning("SETEFI payment - connection timeout")
            return ""
        return self.handle_return_url(item, response)

    def handle_return_url(self, item, response):
        result = response.read().split(":")
        if len(result) != 3:
            logger.warning("SETEFI payment - invalid response")
            return ""
        item.reindexObject()
        return "%s:%s?PaymentID=%s" % (result[1], result[2], result[0])

    def generate_params(self, item, tool):
        context = self.context.aq_inner
        portal_state = getMultiAdapter(
            (context, self.request),
            name=u'plone_portal_state')
        email = item.getEmail()
        fullname = item.getFullname()
        numord = tool.getNextTransitionCode()
        urlback = "%s/%s" % (portal_state.portal_url(),
                              tool.getProperty('urlback'))
        urldone = "%s/%s" % (portal_state.portal_url(),
                              tool.getProperty('urldone'))
        servizio = item.getServizio().replace(".", "").replace("'", " ")
        params = {'id': tool.connection_userid,
                  'password': tool.connection_password,
                  'action': '4',
                  'amt': item.getImporto(),
                  'currencycode': '978',
                  'langid': 'ITA',
                  'responseurl': urldone,
                  'errorurl': urlback,
                  'trackid': numord,
                  'udf1': "Acquisto del servizio: %s" % servizio}
        if email and fullname:
            params['udf2'] = "%s;%s" % (fullname, email)
        item.setCodTrans(numord)
        return params
