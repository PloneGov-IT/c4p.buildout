# -*- coding: utf-8 -*-
from cciaa.portlet.homepage import cciaaPortletHomepageMessageFactory as _
from plone.app.form.widgets.uberselectionwidget import UberSelectionWidget
from plone.app.portlets.portlets import base
from plone.app.vocabularies.catalog import SearchableTextSourceBinder
from plone.memoize.instance import memoize
from plone.portlet.collection import collection
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from zope import schema
from zope.component import getMultiAdapter
from zope.formlib import form
from zope.interface import implements


class INewsPrimoPiano(collection.ICollectionPortlet):
    """A portlet

    It inherits from IPortletDataProvider because for this portlet, the
    data that is being rendered and the portlet assignment itself are the
    same.
    """

    tag = schema.TextLine(title=_(u"Escludi la parola chiave"),
                          description=_(u"Verranno visualizzate solo le notizie che NON contengono questa parola chiave"),
                          required=False,
                          )

    archivio_collection = schema.Choice(title=_(u"Collezione di archivio"),
                                  description=_(u"Collezione da impostare come archivio"),
                                  required=False,
                                  source=SearchableTextSourceBinder({'portal_type': ('Topic', 'Collection')},
                                                                    default_query='path:'))


class Assignment(collection.Assignment):
    """Portlet assignment.

    This is what is actually managed through the portlets UI and associated
    with columns.
    """

    implements(INewsPrimoPiano)
    
    tag = u""
    archivio_collection = None
    
    def __init__(self, header=u"", target_collection=None, limit=None, random=False, show_more=True, show_dates=False, tag=u"", archivio_collection=None):
        collection.Assignment.__init__(self, header, target_collection, limit, random, show_more, show_dates)
        self.tag = tag
        self.archivio_collection = archivio_collection


class Renderer(collection.Renderer):
    """Portlet renderer.

    This is registered in configure.zcml. The referenced page template is
    rendered, and the implicit variable 'view' will refer to an instance
    of this class. Other methods can be added and referenced in the template.
    """

    _template = ViewPageTemplateFile('newsprimopiano.pt')
    
    def __init__(self, *args):
        collection.Renderer.__init__(self, *args)
        
    render = _template
    
    def archivio_url(self):
        collection = self.collection_archivio()
        if collection is None:
            return None
        else:
            return collection.absolute_url()
        
    def archivio_title(self):
        collection = self.collection_archivio()
        if collection is None:
            return None
        else:
            return collection.title
    
    @memoize
    def _standard_results(self):
        collection = self.collection()
        results = collection.queryCatalog()
        if self.data.tag:
            results = [x for x in results if self.data.tag not in str(x.Subject)]
        if self.data.limit and self.data.limit > 0:
            results = results[:self.data.limit]
        return results
    
    @memoize
    def collection_archivio(self):
        """ get the collection the portlet is pointing to"""
        
        collection_path = self.data.archivio_collection
        if not collection_path:
            return None

        if collection_path.startswith('/'):
            collection_path = collection_path[1:]
        
        if not collection_path:
            return None

        portal_state = getMultiAdapter((self.context, self.request), name=u'plone_portal_state')
        portal = portal_state.portal()
        return portal.restrictedTraverse(collection_path, default=None)


class AddForm(base.AddForm):
    """Portlet add form.

    This is registered in configure.zcml. The form_fields variable tells
    zope.formlib which fields to display. The create() method actually
    constructs the assignment that is being added.
    """
    form_fields = form.Fields(INewsPrimoPiano)
    form_fields['target_collection'].custom_widget = UberSelectionWidget
    form_fields['archivio_collection'].custom_widget = UberSelectionWidget

    def create(self, data):
        return Assignment(**data)


class EditForm(base.EditForm):
    """Portlet edit form.

    This is registered with configure.zcml. The form_fields variable tells
    zope.formlib which fields to display.
    """
    form_fields = form.Fields(INewsPrimoPiano)
    form_fields['target_collection'].custom_widget = UberSelectionWidget
    form_fields['archivio_collection'].custom_widget = UberSelectionWidget
