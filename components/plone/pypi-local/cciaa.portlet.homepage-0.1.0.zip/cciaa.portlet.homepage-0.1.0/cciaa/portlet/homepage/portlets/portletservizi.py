# -*- coding: utf-8 -*-
from AccessControl import getSecurityManager
from cciaa.portlet.homepage import cciaaPortletHomepageMessageFactory as _
from plone.app.form.widgets.uberselectionwidget import UberSelectionWidget
from plone.app.vocabularies.catalog import SearchableTextSourceBinder
from plone.memoize.instance import memoize
from plone.portlet.collection.collection import AddForm as OriginalAddForm
from plone.portlet.collection.collection import Assignment as OriginalAssignment
from plone.portlet.collection.collection import EditForm as OriginalEditForm
from plone.portlet.collection.collection import ICollectionPortlet
from plone.portlet.collection.collection import Renderer as OriginalRenderer
from Products.ATContentTypes.interface import IATImage
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from zope import schema
from zope.component import getMultiAdapter
from zope.formlib import form
from zope.interface import implements


class IPortletServizi(ICollectionPortlet):
    """A portlet

    It inherits from IPortletDataProvider because for this portlet, the
    data that is being rendered and the portlet assignment itself are the
    same.
    """

    target_image = schema.Choice(title=_(u"Target image"),
                                  description=_(u"Cerca un'immagine nel portale"),
                                  required=False,
                                  source=SearchableTextSourceBinder({'object_provides': IATImage.__identifier__},
                                                                    default_query='path:'))


class Assignment(OriginalAssignment):
    """Portlet assignment.

    This is what is actually managed through the portlets UI and associated
    with columns.
    """
    
    implements(IPortletServizi)

    target_immagine=None
    

    def __init__(self, header=u"", target_collection=None, limit=None, random=False, show_more=True, show_dates=False,target_image=None):
        self.header = header
        self.target_collection = target_collection
        self.limit = limit
        self.random = random
        self.show_more = show_more
        self.show_dates = show_dates
        self.target_image=target_image

    @property
    def title(self):
        """This property is used to give the title of the portlet in the
        "manage portlets" screen.
        """
        return "Portlet servizio: %s" %self.header


class Renderer(OriginalRenderer):
    """Portlet renderer.

    This is registered in configure.zcml. The referenced page template is
    rendered, and the implicit variable 'view' will refer to an instance
    of this class. Other methods can be added and referenced in the template.
    """

    render = ViewPageTemplateFile('portletservizi.pt')

    @memoize
    def getImage(self):
        image_path = self.data.target_image
        if not image_path:
            return None

        if image_path.startswith('/'):
            image_path = image_path[1:]

        if not image_path:
            return None

        portal_state = getMultiAdapter((self.context, self.request),
                                       name=u'plone_portal_state')
        portal = portal_state.portal()
        if isinstance(image_path, unicode):
            # restrictedTraverse accepts only strings
            image_path = str(image_path)

        result = portal.unrestrictedTraverse(image_path, default=None)
        if result is not None:
            sm = getSecurityManager()
            if not sm.checkPermission('View', result):
                result = None
        return result


class AddForm(OriginalAddForm):
    """Portlet add form.

    This is registered in configure.zcml. The form_fields variable tells
    zope.formlib which fields to display. The create() method actually
    constructs the assignment that is being added.
    """
    form_fields = form.Fields(IPortletServizi)
    form_fields['target_collection'].custom_widget = UberSelectionWidget
    form_fields['target_image'].custom_widget = UberSelectionWidget

    def create(self, data):
        return Assignment(**data)


class EditForm(OriginalEditForm):
    """Portlet edit form.

    This is registered with configure.zcml. The form_fields variable tells
    zope.formlib which fields to display.
    """
    form_fields = form.Fields(IPortletServizi)
    form_fields['target_collection'].custom_widget = UberSelectionWidget
    form_fields['target_image'].custom_widget = UberSelectionWidget
    
    label = _(u"Modifica la Portlet Servizi")
