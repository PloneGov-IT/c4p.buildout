# -*- coding: utf-8 -*-
from cciaa.portlet.homepage import cciaaPortletHomepageMessageFactory as _
from plone.app.form.widgets.uberselectionwidget import UberSelectionWidget
from plone.app.portlets.portlets import base
from plone.portlet.collection import collection
from Products.CMFCore.utils import getToolByName
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from zope import schema
from zope.formlib import form
from zope.interface import implements


class INewsEvidenza(collection.ICollectionPortlet):
    """A portlet

    It inherits from IPortletDataProvider because for this portlet, the
    data that is being rendered and the portlet assignment itself are the
    same.
    """
    tag = schema.TextLine(title=_(u"Parola chiave"),
                             description=_(u"Verranno visualizzate solo le notizie contenenti questa parola chiave"),
                             required=True)


class Assignment(collection.Assignment):
    """Portlet assignment.

    This is what is actually managed through the portlets UI and associated
    with columns.
    """

    implements(INewsEvidenza)

    tag = u""

    def __init__(self, header=u"", target_collection=None, limit=None, random=False, show_more=True, show_dates=False, tag=u""):
        collection.Assignment.__init__(self, header, target_collection, limit, random, show_more, show_dates)
        self.tag = tag


class Renderer(collection.Renderer):
    """Portlet renderer.

    This is registered in configure.zcml. The referenced page template is
    rendered, and the implicit variable 'view' will refer to an instance
    of this class. Other methods can be added and referenced in the template.
    """

    _template = ViewPageTemplateFile('newsevidenza.pt')

    def __init__(self, *args):
        collection.Renderer.__init__(self, *args)

    render = _template

    def _standard_results(self):
        results = []
        collection = self.collection()
        if collection.portal_type == "Topic":
            query = collection.buildQuery()
        else:
            query = self.getCollectionQuery(collection)
        catalog = getToolByName(collection, 'portal_catalog')
        t = self.data.tag.encode('utf-8')
        if query.get('Subject', None):
            query['Subject']['query'] = query['Subject']['query'] + [t, ]
            query['Subject']['operator'] = 'and' # BBB this!
        else:
            query['Subject'] = {'operator': 'or', 'query': [t, ]}
        results = catalog(**query)
        if self.data.limit and self.data.limit > 0:
            results = results[:self.data.limit]
        return results

    def getCollectionQuery(self, collection):
        """
        """
        query = {}
        for item in collection.getRawQuery():
            index = item.get('i')
            value = item.get('v')
            query[index] = {'query': value}
        return query


class AddForm(base.AddForm):
    """Portlet add form.

    This is registered in configure.zcml. The form_fields variable tells
    zope.formlib which fields to display. The create() method actually
    constructs the assignment that is being added.
    """
    form_fields = form.Fields(INewsEvidenza)
    form_fields['target_collection'].custom_widget = UberSelectionWidget

    def create(self, data):
        return Assignment(**data)


class EditForm(base.EditForm):
    """Portlet edit form.

    This is registered with configure.zcml. The form_fields variable tells
    zope.formlib which fields to display.
    """
    form_fields = form.Fields(INewsEvidenza)
    form_fields['target_collection'].custom_widget = UberSelectionWidget