# -*- coding: utf-8 -*-
from zope.i18nmessageid import MessageFactory
cciaaPortletHomepageMessageFactory = MessageFactory('cciaa.portlet.homepage')
