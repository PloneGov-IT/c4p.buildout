.. contents::

.. Note!
   -----
   Update the following URLs to point to your:

   - code repository
   - bug tracker
   - questions/comments feedback mail
   (do not set a real mail, to avoid spams)

   Or remove it if not used.

- Code repository: http://svn.somewhere.com/...
- Questions and comments to somemailing_list
- Report bugs at http://bug.somewhere.com/..

===================
redturtle.zodbtools
===================

Some useful tools to manage ZODB operations.
For the time being just a view is provided at zope application level that 
allows everyone to pack the ZODB given that the request comes from localhost.
   
This is useful for managing packs in non zeo sites.

To use this view just point your browser to 
`http://localhost:$PORT/packer_view?days:float=$DAYS`
where `$PORT` is the zope instance port and `$DAYS` is the number of days you 
want to keep.

******************************************
Creating a packer executable with buildout
******************************************

You may find useful to include a part like this one in the buildout::

 [packer]
 recipe = collective.recipe.template
 input = ${buildout:directory}/templates/packer.in
 output = ${buildout:directory}/bin/packer
 mode = 700
 days=7
 host=127.0.0.1
 port=${instance:http-address}

where ``templates/packer.in`` could be something like::

 #!${buildout:directory}/bin/zopepy
 from urllib2 import urlopen
 days = "${packer:days}"
 host = "${packer:host}"
 port = "${packer:port}"
 packurl = ("http://%s:%s/packer_view?days:float=%s"
           ) % (host, port, days)
 print urlopen(packurl)
