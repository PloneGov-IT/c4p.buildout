# -*- coding: utf-8 -*-
from AccessControl import Unauthorized
from Products.Five.browser import BrowserView
from logging import getLogger
from plone.memoize.view import memoize
from redturtle.zodbutils.config import PROJECTNAME

class View(BrowserView):
    '''
    This is the view that packs the DB
    '''
    success_message = "^_^ DB has been packed! ^_^"
    failure_message = "T_T Packing failed T_T"
    
    @property
    @memoize
    def logger(self):
        '''
        Returns a logger for this view        
        '''
        return getLogger(PROJECTNAME)

    def additional_security_checks(self):
        '''
        Perform security checks, for example we want that all our requests 
        should come from 127.0.0.1
        TODO: This function should wake up adapters to perform the checks
        '''
        if self.request.REMOTE_ADDR!='127.0.0.1':
            raise Unauthorized('Accepting only request coming from 127.0.0.1')

    def pack(self):
        '''
        We expect in the query a numerical parameter passed as days:float
        '''
        self.additional_security_checks()
        days=self.request.get('days')
        self.context.Control_Panel.Database.manage_pack(days=days)
        return 'OK'

    def report_success(self):
        '''
        What to tell to the user in case of success
        '''
        self.logger.info(self.success_message)
        return self.success_message

    def report_failure(self):
        '''
        What to tell to the user in case of failure
        '''
        self.logger.exception(self.failure_message)
        return self.failure_message

    def __call__(self):
        '''
        Try to pack and return OK is everything goes fine, otherwise return KO
        '''
        try:
            self.pack()
            return self.report_success()
        except:
            return self.report_failure()
