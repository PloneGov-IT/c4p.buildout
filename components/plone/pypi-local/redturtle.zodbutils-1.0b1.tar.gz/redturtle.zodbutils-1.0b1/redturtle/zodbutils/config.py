"""Common configuration constants
"""
PROJECTNAME = 'redturtle.zodbutils'
