# -*- coding: utf-8 -*-

from Products.CMFCore.DirectoryView import registerDirectory
import config

GLOBALS = globals()

registerDirectory('skins', GLOBALS)