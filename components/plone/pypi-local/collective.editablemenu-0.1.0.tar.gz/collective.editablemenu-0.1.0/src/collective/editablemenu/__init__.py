# -*- coding: utf-8 -*-
"""Init and utils."""

from zope.i18nmessageid import MessageFactory

_ = MessageFactory('collective.editablemenu')

import logging
logger = logging.getLogger('collective.editablemenu')
