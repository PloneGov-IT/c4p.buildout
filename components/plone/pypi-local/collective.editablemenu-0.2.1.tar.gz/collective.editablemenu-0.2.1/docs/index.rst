====================
collective.editablemenu
====================

User documentation
