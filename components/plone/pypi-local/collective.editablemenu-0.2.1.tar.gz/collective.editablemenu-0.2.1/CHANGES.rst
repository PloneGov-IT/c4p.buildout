Changelog
=========


0.2.1 (2016-01-11)
------------------

- Fix js call [cekk]


0.2.0 (2016-01-11)
------------------

- Fix registry problems [cekk]


0.1.0 (2016-01-05)
------------------

- Initial release.
  [cekk]
