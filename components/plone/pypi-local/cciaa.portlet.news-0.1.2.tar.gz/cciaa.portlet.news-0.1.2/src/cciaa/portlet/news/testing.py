# -*- coding: utf-8 -*-
from plone.app.robotframework.testing import REMOTE_LIBRARY_BUNDLE_FIXTURE
from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import PLONE_FIXTURE
from plone.app.testing import PloneSandboxLayer
from plone.testing import z2

import cciaa.portlet.news


class CciaaPortletNewsLayer(PloneSandboxLayer):

    defaultBases = (PLONE_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        self.loadZCML(package=cciaa.portlet.news)

    def setUpPloneSite(self, portal):
        applyProfile(portal, 'cciaa.portlet.news:default')


CCIAA_PORTLET_NEWS_FIXTURE = CciaaPortletNewsLayer()


CCIAA_PORTLET_NEWS_INTEGRATION_TESTING = IntegrationTesting(
    bases=(CCIAA_PORTLET_NEWS_FIXTURE,),
    name='CciaaPortletNewsLayer:IntegrationTesting'
)


CCIAA_PORTLET_NEWS_FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(CCIAA_PORTLET_NEWS_FIXTURE,),
    name='CciaaPortletNewsLayer:FunctionalTesting'
)


CCIAA_PORTLET_NEWS_ACCEPTANCE_TESTING = FunctionalTesting(
    bases=(
        CCIAA_PORTLET_NEWS_FIXTURE,
        REMOTE_LIBRARY_BUNDLE_FIXTURE,
        z2.ZSERVER_FIXTURE
    ),
    name='CciaaPortletNewsLayer:AcceptanceTesting'
)
