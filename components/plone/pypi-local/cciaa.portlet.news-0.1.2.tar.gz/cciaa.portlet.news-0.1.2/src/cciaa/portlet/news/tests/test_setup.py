# -*- coding: utf-8 -*-
"""Setup tests for this package."""
from cciaa.portlet.news.testing import CCIAA_PORTLET_NEWS_INTEGRATION_TESTING  # noqa
from plone import api

import unittest


class TestSetup(unittest.TestCase):
    """Test that cciaa.portlet.news is properly installed."""

    layer = CCIAA_PORTLET_NEWS_INTEGRATION_TESTING

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer['portal']
        self.installer = api.portal.get_tool('portal_quickinstaller')

    def test_product_installed(self):
        """Test if cciaa.portlet.news is installed."""
        self.assertTrue(self.installer.isProductInstalled(
            'cciaa.portlet.news'))

    def test_browserlayer(self):
        """Test that ICciaaPortletNewsLayer is registered."""
        from cciaa.portlet.news.interfaces import (
            ICciaaPortletNewsLayer)
        from plone.browserlayer import utils
        self.assertIn(ICciaaPortletNewsLayer, utils.registered_layers())


class TestUninstall(unittest.TestCase):

    layer = CCIAA_PORTLET_NEWS_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer['portal']
        self.installer = api.portal.get_tool('portal_quickinstaller')
        self.installer.uninstallProducts(['cciaa.portlet.news'])

    def test_product_uninstalled(self):
        """Test if cciaa.portlet.news is cleanly uninstalled."""
        self.assertFalse(self.installer.isProductInstalled(
            'cciaa.portlet.news'))
