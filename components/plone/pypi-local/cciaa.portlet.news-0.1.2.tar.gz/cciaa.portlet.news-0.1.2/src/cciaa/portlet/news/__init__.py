# -*- coding: utf-8 -*-
"""Init and utils."""

from zope.i18nmessageid import MessageFactory
_ = MessageFactory('cciaa.portlet.news')

import logging
logger = logging.getLogger("cciaa.portlet.news")
