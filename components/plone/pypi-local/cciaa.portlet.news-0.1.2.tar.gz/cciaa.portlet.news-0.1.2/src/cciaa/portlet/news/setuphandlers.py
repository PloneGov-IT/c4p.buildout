# -*- coding: utf-8 -*-
from plone import api


def post_install(context):
    """Post install script"""
    if context.readDataFile('cciaaportletnews_default.txt') is None:
        return
    add_image_scale(context)


def add_image_scale(context):
    portal_properties = api.portal.get_tool(name='portal_properties')
    imaging_properties = getattr(
        portal_properties,
        'imaging_properties',
        None)
    if imaging_properties:
        old_properties = imaging_properties.getProperty('allowed_sizes', [])
        if old_properties:
            sizes = [x for x in old_properties]
            new_sizes = [
                '700x400 700:400',
                '300x150 300:150',
            ]
            for size in new_sizes:
                if size not in sizes:
                    sizes.append(size)
            imaging_properties.manage_changeProperties(allowed_sizes=sizes)
