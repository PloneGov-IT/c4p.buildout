# -*- coding: utf-8 -*-
from cciaa.portlet.news import _
from cciaa.portlet.news import logger
from plone.app.form.widgets.uberselectionwidget import UberSelectionWidget
from plone.app.portlets.portlets import base
from plone.app.vocabularies.catalog import SearchableTextSourceBinder
from plone.memoize.instance import memoize
from plone.portlet.collection.collection import Assignment as BaseCollectionPortletAssignment
from plone.portlet.collection.collection import ICollectionPortlet
from plone.portlet.collection.collection import Renderer as BaseCollectionPortletRenderer
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from zope import schema
from zope.formlib import form
from zope.interface import implements
from plone import api
from Products.CMFPlone.utils import base_hasattr


class ICCIAANewsPortlet(ICollectionPortlet):
    """A portlet which renders the results of a collection object.
    """

    # header = schema.TextLine(
    #     title=_(u"Portlet header"),
    #     description=_(u"Title of the rendered portlet"),
    #     required=True)
    #
    # target_collection = schema.Choice(
    #     title=_(u"Target collection"),
    #     description=_(u"Find the collection which provides the items to list"),
    #     required=True,
    #     source=SearchableTextSourceBinder(
    #         {'portal_type': ('Topic', 'Collection')},
    #         default_query='path:'))
    #
    # limit = schema.Int(
    #     title=_(u"Limit"),
    #     description=_(u"Specify the maximum number of items to show in the "
    #                   u"portlet. Leave this blank to show all items."),
    #     required=False)
    #
    # random = schema.Bool(
    #     title=_(u"Select random items"),
    #     description=_(u"If enabled, items will be selected randomly from the "
    #                   u"collection, rather than based on its sort order."),
    #     required=True,
    #     default=False)
    #
    # show_more = schema.Bool(
    #     title=_(u"Show more... link"),
    #     description=_(u"If enabled, a more... link will appear in the footer "
    #                   u"of the portlet, linking to the underlying "
    #                   u"Collection."),
    #     required=True,
    #     default=True)
    #
    # show_dates = schema.Bool(
    #     title=_(u"Show dates"),
    #     description=_(u"If enabled, effective dates will be shown underneath "
    #                   u"the items listed."),
    #     required=True,
    #     default=False)
    target_collection = schema.Choice(
        title=_(u"Target collection"),
        description=_(u"Find the collection which provides the items to list"),
        required=False,
        source=SearchableTextSourceBinder(
            {'portal_type': ('Topic', 'Collection')},
            default_query='path:'))

    show_keywords = schema.Bool(
        title=_(u"Show keywords"),
        description=_(u"If enabled, item's keywords will be shown."),
        required=False,
        default=False)

    big_news = schema.Choice(
        title=_("big_news_label",
                default=u'Big news'),
        description=_(
            "big_news_help",
            default=u'Select an object in the site that will apeears in the "Big news" section.'),
        required=False,
        source=SearchableTextSourceBinder(
            {'sort_on': 'getObjPositionInParent'},
            default_query='path:'))

    vertical_news_1 = schema.Choice(
        title=_("vertical_news_1",
                default=u'First vertical news'),
        description=_(
            "vertical_news_1_help",
            default=u'Select an object in the site that will apeears in the first vertical section of the news.'),
        required=False,
        source=SearchableTextSourceBinder(
            {'sort_on': 'getObjPositionInParent'},
            default_query='path:'))

    vertical_news_2 = schema.Choice(
        title=_("vertical_news_2",
                default=u'Second vertical news'),
        description=_(
            "vertical_news_2_help",
            default=u'Select an object in the site that will apeears in the second vertical section of the news.'),
        required=False,
        source=SearchableTextSourceBinder(
            {'sort_on': 'getObjPositionInParent'},
            default_query='path:'))

    link_text = schema.TextLine(
        title=_("custom_more_label",
                default=u'Custom "more..." label'),
        description=_(
            "custom_more_label_help",
            default=u'Fill this to show a different label for the "more..." link'),
        required=False)

    target_more = schema.Choice(
        title=_("custom_more_target_label",
                default=u'Custom "more..." target'),
        description=_(
            "custom_more_target_help",
            default=u'Select an object in the site, for the "more..." link. If empty, the link will be the collection.'),
        required=False,
        source=SearchableTextSourceBinder(
            {'sort_on': 'getObjPositionInParent'},
            default_query='path:'))

    css_class = schema.TextLine(
        title=_("css_class_label",
                default=u'Portlet\'s CSS class'),
        description=_(
            "css_class_label_help",
            default=u'Fill this to  assign a CSS class to the portlet (for style purpose)'),
        required=False)


class Assignment(BaseCollectionPortletAssignment):
    """
    Portlet assignment.
    This is what is actually managed through the portlets UI and associated
    with columns.
    """

    implements(ICCIAANewsPortlet)

    target_collection = None
    show_keywords = False
    big_news = None
    vertical_news_1 = None
    vertical_news_2 = None
    link_text = u""
    target_more = None
    css_class = ""

    def __init__(self, header=u"", target_collection=None, limit=None,
                 random=False, show_more=True, show_dates=False,
                 exclude_context=True, link_text=u"", target_more=None,
                 big_news=None, vertical_news_1=None, vertical_news_2=None,
                 css_class="", show_keywords=False):
        BaseCollectionPortletAssignment.__init__(
            self,
            header=header,
            target_collection=target_collection,
            limit=limit, random=random,
            show_more=show_more,
            show_dates=show_dates,
            exclude_context=exclude_context)

        self.show_keywords = show_keywords
        self.big_news = big_news
        self.vertical_news_1 = vertical_news_1
        self.vertical_news_2 = vertical_news_2
        self.link_text = link_text
        self.target_more = target_more
        self.css_class = css_class


class Renderer(BaseCollectionPortletRenderer):

    _template = ViewPageTemplateFile('cciaa_news_portlet.pt')
    render = _template

    @property
    def available(self):
        if self.results() or self.big_news_item or self.vertical_news_items:
            return True
        return False

    def is_expired(self, item):
        """check if an item is exired or not"""
        if base_hasattr(item, 'expires'):
            return item.expires().isPast()

    @property
    @memoize
    def big_news_item(self):
        if self.data.big_news:
            item = api.content.get(self.data.big_news)
            if not item:
                return None
            return not self.is_expired(item) and item or None
        return None

    @property
    @memoize
    def vertical_news_items(self):
        items = []
        if self.data.vertical_news_1:
            vertical_news_1 = api.content.get(self.data.vertical_news_1)
            if vertical_news_1:
                if not self.is_expired(vertical_news_1):
                    items.append(vertical_news_1)
        if self.data.vertical_news_2:
            vertical_news_2 = api.content.get(self.data.vertical_news_2)
            if vertical_news_2:
                if not self.is_expired(vertical_news_2):
                    items.append(vertical_news_2)
        return items

    @property
    @memoize
    def evidence_uids(self):
        uids = []
        if self.big_news_item:
            uids.append(self.big_news_item.UID())
        for item in self.vertical_news_items:
            uids.append(item.UID())
        return uids

    @property
    @memoize
    def target_more_item(self):
        if self.data.target_more:
            return api.content.get(self.data.target_more)
        return None

    def get_image_tag(self, item, scale):
        """
        check if an image is set, and return its html tag
        """
        try:
            return item.unrestrictedTraverse('@@images').scale(
                'image',
                scale=scale).tag()
        except AttributeError:
            # The object doesn't have an image field
            return ""

    def _standard_results(self):
        results = []
        query_results = []
        collection = self.collection()
        if collection is not None:
            context_path = '/'.join(self.context.getPhysicalPath())
            exclude_context = getattr(self.data, 'exclude_context', False)
            limit = self.data.limit
            if limit and limit > 0:
                if self.evidence_uids:
                    limit += len(self.evidence_uids)
                # pass on batching hints to the catalog
                query_results = collection.queryCatalog(
                    batch=True, b_size=limit  + exclude_context)
                query_results = query_results._sequence
            else:
                query_results = collection.queryCatalog()
            if exclude_context or self.evidence_uids:
                for brain in query_results:
                    if exclude_context and brain.getPath() == context_path:
                        continue
                    if self.evidence_uids and brain.UID in self.evidence_uids:
                        continue
                    results.append(brain)
            else:
                results = query_results

            if limit and limit > 0:
                results = results[:self.data.limit]
        return results

    def _random_results(self):
        # intentionally non-memoized
        results = []
        query_results = []
        collection = self.collection()
        if collection is not None:
            context_path = '/'.join(self.context.getPhysicalPath())
            exclude_context = getattr(self.data, 'exclude_context', False)
            query_results = collection.queryCatalog(sort_on=None)
            if query_results is None:
                return []
            limit = self.data.limit and min(len(query_results), self.data.limit) or 1

            if exclude_context or self.evidence_uids:
                for brain in query_results:
                    if exclude_context and brain.getPath() == context_path:
                        continue
                    if self.evidence_uids and brain.UID in self.evidence_uids:
                        continue
                    results.append(brain)
            else:
                results = query_results
            if len(results) < limit:
                limit = len(results)
            results = random.sample(results, limit)

        return results

class AddForm(base.AddForm):

    form_fields = form.Fields(ICCIAANewsPortlet)
    form_fields['target_collection'].custom_widget = UberSelectionWidget
    form_fields['big_news'].custom_widget = UberSelectionWidget
    form_fields['vertical_news_1'].custom_widget = UberSelectionWidget
    form_fields['vertical_news_2'].custom_widget = UberSelectionWidget
    form_fields['target_more'].custom_widget = UberSelectionWidget

    form_fields = form_fields.select(
            'header',
            'target_collection',
            'limit',
            'random',
            'show_more',
            'show_dates',
            'show_keywords',
            'big_news',
            'vertical_news_1',
            'vertical_news_2',
            'link_text',
            'target_more',
            'css_class'
            )

    label = _(u"Add CCIAA News portlet")
    description = _(u"This portlet displays a listing of items from a "
                    u"Collection.")

    def create(self, data):
        return Assignment(**data)


class EditForm(base.EditForm):

    form_fields = form.Fields(ICCIAANewsPortlet)
    form_fields['target_collection'].custom_widget = UberSelectionWidget
    form_fields['big_news'].custom_widget = UberSelectionWidget
    form_fields['vertical_news_1'].custom_widget = UberSelectionWidget
    form_fields['vertical_news_2'].custom_widget = UberSelectionWidget
    form_fields['target_more'].custom_widget = UberSelectionWidget

    form_fields = form_fields.select(
            'header',
            'target_collection',
            'limit',
            'random',
            'show_more',
            'show_dates',
            'show_keywords',
            'big_news',
            'vertical_news_1',
            'vertical_news_2',
            'link_text',
            'target_more',
            'css_class'
            )

    label = _(u"Edit CCIAA News portlet")
    description = _(u"This portlet displays a listing of items from a "
                    u"Collection.")
