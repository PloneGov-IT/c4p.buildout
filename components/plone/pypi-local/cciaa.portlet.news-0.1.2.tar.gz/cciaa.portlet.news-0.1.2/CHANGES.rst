Changelog
=========


0.1.2 (2016-01-05)
------------------

- Initial release.
  [cekk]
