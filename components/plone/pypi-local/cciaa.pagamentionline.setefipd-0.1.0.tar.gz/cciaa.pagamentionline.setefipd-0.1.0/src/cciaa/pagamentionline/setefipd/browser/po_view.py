# -*- coding: utf-8 -*-
from cciaa.pagamentionline.setefi import logger
from cciaa.pagamentionline.setefi.browser.po_view import CommittedView as BaseCommittedView
from cciaa.pagamentionline.setefi.browser.po_view import DoneView as BaseDoneView
from cciaa.pagamentionline.setefi.browser.po_view import SetefiPOSupportView
from lxml import etree
from Products.CMFCore.utils import getToolByName
from zope.component import getMultiAdapter


class CommittedView(BaseCommittedView):
    """
    if everything is ok, print a redirect url that bank's webservice
    uses to call the real done view
    """

    def __call__(self):
        request = self.request.form
        responsecode = request.get("responsecode", '')
        if responsecode in ["00", "000"] and request.get("result", '') == "APPROVED":
            orderid = self.request.form.get("merchantorderid", '')
            auth = self.request.form.get("authorizationcode", '')
            camcom_pagamentionline_tool = getToolByName(self.context, 'camcom_pagamentionline_tool')
            pagamento_brain = camcom_pagamentionline_tool.getPagamentoOnlineByCodeTrans(orderid)
            if not pagamento_brain:
                return "Elemento non trovato"
            pagamento_item = pagamento_brain._unrestrictedGetObject()
            pagamento_item.setEsito("OK")
            pagamento_item.setCodAut(auth)
            pagamento_item.reindexObject()
            camcom_pagamentionline_tool.notify(pagamento_item)
            return "REDIRECT=%s/po_done?orderid=%s" % (
                self.context.absolute_url(),
                orderid)


class DoneView(BaseDoneView):
    """
    Update AT infos and print infos to the user
    """

    def getPagamentoItem(self):
        orderid = self.request.form.get("orderid", '')
        camcom_pagamentionline_tool = getToolByName(self.context, 'camcom_pagamentionline_tool')
        return camcom_pagamentionline_tool.getPagamentoOnlineByCodeTrans(orderid)._unrestrictedGetObject()


class SetefiPOSupportPDView(SetefiPOSupportView):
    """ Helper view that send request to the server.
    """

    def handle_return_url(self, item, response):
        result = response.read()
        try:
            root = etree.fromstring(result)
        except etree.XMLSyntaxError as e:
            logger.exception(e)
            logger.error("Invalid response from the ws: %s" % result)
            return ""
        paymentid = root.find('paymentid')
        hostedpageurl = root.find('hostedpageurl')
        if paymentid is None or hostedpageurl is None:
            logger.error("Invalid response from the ws: no paymentid or hostedpageurl given.")
            return ""
        item.reindexObject()
        return "%s?paymentid=%s" % (hostedpageurl.text, paymentid.text)

    def generate_params(self, item, tool):
        context = self.context.aq_inner
        portal_state = getMultiAdapter(
            (context, self.request),
            name=u'plone_portal_state')
        numord = tool.getNextTransitionCode()
        urlback = "%s/%s" % (portal_state.portal_url(),
                             tool.getProperty('urlback'))
        urldone = "%s/%s" % (portal_state.portal_url(),
                             tool.getProperty('urldone'))
        servizio = item.getServizio().replace(".", "").replace("'", " ")
        item.setCodTrans(numord)
        return {
            'id': tool.connection_userid,
            'password': tool.connection_password,
            'operationType': 'initialize',
            'amount': item.getImporto(),
            'currencycode': '978',
            'language': 'ITA',
            'responseTomerchantUrl': urldone,
            'recoveryUrl': urlback,
            'merchantOrderId': numord,
            'description': "Acquisto del servizio: %s" % servizio,
            'cardHolderName': item.getFullname(),
            'cardHolderEmail': item.getEmail(),
        }
