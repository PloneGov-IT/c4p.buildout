Changelog
=========


0.2.0 (2016-04-28)
------------------

- Add "CAPTURED" in allowed states in CommittedView [cekk]


0.1.0 (2016-01-05)
------------------

- Initial release.
  [cekk]
