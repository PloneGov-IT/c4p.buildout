# -*- coding: utf-8 -*-
from zope.schema.vocabulary import SimpleVocabulary, SimpleTerm
from Products.CMFCore.utils import getToolByName
from plone import api
from Products.Archetypes.utils import DisplayList


class PaymentServicesVocabularyFactory(object):


    def __call__(self, context):
        """Ottiene i servizi possibili per i pagamenti"""
        servizi = [SimpleTerm(title="", value="[Selezionare un servizio]")]
        potool = api.portal.get_tool(name='camcom_pagamentionline_tool')
        pol_types = potool.getProperty('pol_types')
        for x in pol_types:
            servizi.append(SimpleTerm(title=x,value=x))
        return SimpleVocabulary(servizi)

PaymentServicesVocabulary = PaymentServicesVocabularyFactory()
