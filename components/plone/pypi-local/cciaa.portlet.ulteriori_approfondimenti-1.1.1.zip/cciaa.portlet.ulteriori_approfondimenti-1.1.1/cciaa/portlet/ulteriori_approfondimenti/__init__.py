# -*- coding: utf-8 -*-

from zope.i18nmessageid import MessageFactory
UlterioriApprofondimentiMessageFactory = MessageFactory('cciaa.portlet.ulteriori_approfondimenti')

