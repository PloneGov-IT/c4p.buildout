# -*- coding: utf-8 -*-

from Acquisition import aq_inner
from DateTime import DateTime
from Products.CMFCore.utils import getToolByName
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from plone.app.layout.viewlets.common import FooterViewlet as PloneFooterViewlet
from plone.app.layout.viewlets.common import GlobalSectionsViewlet
from plone.app.layout.viewlets.common import PathBarViewlet as PlonePathBarViewlet
from zope.component import getMultiAdapter


class C4PGlobalSectionsViewlet(GlobalSectionsViewlet):
    index = ViewPageTemplateFile('templates/sections.pt')

    def update(self):
        context = aq_inner(self.context)
        portal_tabs_view = getMultiAdapter((context, self.request),
                                           name='portal_tabs_view')
        self.portal_tabs = portal_tabs_view.topLevelTabs()

        self.selected_tabs = self.selectedTabs(portal_tabs=self.portal_tabs)
        self.selected_portal_tab = self.selected_tabs['portal']
        self.date_infos = self.getDateInfos()

    def getDateInfos(self):
        """
        take the current date and return a dict with some translated parts
        """
        ts = getToolByName(self.context, 'translation_service')
        now = DateTime()
        dow = now.dow()
        dow_label = ts.day_msgid(dow)
        month_label = ts.month_msgid(now.month())
        return {'date': now,
                'year': now.year(),
                'day': now.day(),
                'dayofweek_label': dow_label,
                'month_label': month_label}


class PathBarViewlet(PlonePathBarViewlet):
    index = ViewPageTemplateFile('templates/path_bar.pt')


class FooterViewlet(PloneFooterViewlet):
    
    def build_copyright(self):
        year = DateTime().year()
        site = getToolByName(self.context, 'portal_url').getPortalObject()
        site_name = site.getProperty('short_title') or site.title
        return "%d &copy; %s" % (year, site_name)
    