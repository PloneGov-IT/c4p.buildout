# -*- coding: utf-8 -*-
# $Id: actionsportlet.py 86466 2009-05-20 09:33:08Z piv $
"""Actions portlet: Render custom"""
from AccessControl import getSecurityManager

from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from Products.CMFCore.utils import getToolByName

from collective.portlet.actions.actionsportlet import Renderer as BaseRenderer
from urllib import quote_plus


class Renderer(BaseRenderer):
    """Actions portlet renderer."""

    render = ViewPageTemplateFile('templates/actionsportlet.pt')

    def getUserInfo(self):
        pm = getToolByName(self.context, 'portal_membership')
        if pm.isAnonymousUser():
            return {}
        sm = getSecurityManager()
        user = pm.getAuthenticatedMember()
        userid = user.id
        user_info = {}
        if sm.checkPermission('Portlets: Manage own portlets', self.context):
            user_info['url'] = self.context.portal_url() + '/dashboard'
        else:
            if userid.startswith('http:') or userid.startswith('https:'):
                user_info['url'] = self.context.portal_url() + '/author/?author=' + userid
            else:
                user_info['url'] = self.context.portal_url() + '/author/' + quote_plus(userid)
        if user.getProperty('fullname'):
            user_info['name'] = user.getProperty('fullname')
        else:
            user_info['name'] = userid
        return user_info
