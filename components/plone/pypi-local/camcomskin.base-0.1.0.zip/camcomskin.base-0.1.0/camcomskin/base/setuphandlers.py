# -*- coding: utf-8 -*-

def setupVarious(context):

    if context.readDataFile('camcomskin.base_various.txt') is None:
        return

    # Add additional setup code here
