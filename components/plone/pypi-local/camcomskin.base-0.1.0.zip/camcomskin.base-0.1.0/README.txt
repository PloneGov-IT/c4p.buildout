Tema CCIAA Generico
===================

Copyright nel footer
--------------------

La riga di copyright nel footer è automaticamente generata come...

::

    2013 &copy; Camera di Commercio di Xxxx

L'anno è automaticamente aggiornato, e il nome del sito è di default quello del sito Plone.
Per usarne una forma più breve basta aggiungere al sito Plone una property ``short_title``, che
avrà la precedenza sulla property precedente.

Portlet loghi nel footer
------------------------

Il nome della portlet del essere "Loghi", se no non sono applicati i CSS corretti.
