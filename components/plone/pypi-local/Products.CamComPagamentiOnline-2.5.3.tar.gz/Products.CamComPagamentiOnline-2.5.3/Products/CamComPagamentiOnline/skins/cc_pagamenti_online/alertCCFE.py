## Script (Python) "alertCCFE"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=message_type, **kw_args
##title=Invia una mail per avvertire di eventi che riguardano i pagamenti on-line
##

if False:
    # per fregare il pre-commit-hook
    context = message_type = container = kw_args = None

request = context.REQUEST
response = request.RESPONSE
portal = context.portal_url.getPortalObject()

message_type = int(message_type)

from Products.CMFCore.utils import getToolByName

cciaa_po_tool = getToolByName(container, 'camcom_pagamentionline_tool', None)
mailhost = getToolByName(container, 'MailHost', None)

mto = cciaa_po_tool.getProperty("email_notification") or portal.getProperty('email_from_address')

msg = None

if message_type==1:
    # *** Il MAC dei dati in risposta dal servizio non è corretto ***
    msg = """Questo messaggio è una notifica automatica scatenata dai pagamenti on-line.

La verifica dei dati ottenuti in risposta dal servizio di pagamento non combaciano con il MAC di risposta.
Questo può voler dire che qualcosa durante il tragitto di ritorno ha modificato i dati di risposta del server.

Se l'utente aveva specificato un indirizzo e-mail, potrebbe aver ricevuto un riepilogo fasullo dei dati del pagamento.

Si consiglia di contattare l'utente che ha generato questo pagamento:
%s"""
    msg = msg % kw_args['at_url']
    subject = "Verifica del MAC fallita"

else:
    message_type = None

if message_type:
    try:
        mailhost.secureSend(msg, mto=mto, mfrom=portal.getProperty('email_from_address'), subject=subject, charset='utf-8')
    except Exception, inst:
        cciaa_po_tool.log_error("ATTENZIONE! Errore nell'invio via mail del seguente messaggio:\n%s\n%s" % (msg, inst))

