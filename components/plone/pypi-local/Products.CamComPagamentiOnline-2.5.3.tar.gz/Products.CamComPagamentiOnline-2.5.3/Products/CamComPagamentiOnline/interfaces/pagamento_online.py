from zope.interface import Interface


class IPagamentoOnline(Interface):
    """Registrazione di un pagamento on-line"""


class IPagamentoOnlineConnection(Interface):
    """Registrazione di un utility per i pagamenti on-line"""


class ICamComPagamentiOnlineLayer(Interface):
    """MArker interface for browserlayer"""
