# -*- coding: utf-8 -*-

from urllib import urlencode
from base64 import encodestring
from md5 import md5
from sha import sha

from Products.CamComPagamentiOnline import logger

def get_mac(codTrans, importo, chiave, algoritmo='md5', debug=False):
    '''
    >>> codTrans="testCILME534"
    >>> importo="1"
    >>> chiave = "esempiodicalcolomac"
    >>> algoritmo = 'md5'
    >>> mac = get_mac(codTrans, importo, chiave)
    >>> assert mac=="ZjRkZDdkNWNmYThlZmYyNTJiN2U1ZmI2MDJlNjM5NDI%3D"
    >>> mac = get_mac(codTrans, importo, chiave, 'sha')
    >>> assert mac=="992e40c00b79ad1a6e4a5a8c61e776e696796a79"    
    '''
    divisa="EUR"
    if debug:
        print codTrans, divisa, importo, chiave
    txt = "".join(("codTrans=%s" % codTrans,
           "divisa=%s" % divisa,
           "importo=%s" % importo,
           chiave))
    algoritmo = algoritmo.lower()
    if algoritmo=='md5':
        digest = encodestring(md5(txt).hexdigest()).strip()
        encoded = urlencode({'': digest})
        if debug:
            logger.info(algoritmo)
            logger.info(txt)
            logger.info(digest)
            logger.info(encoded[1:])
        return encoded[1:]
    elif algoritmo=='sha':
        digest = sha(txt).hexdigest().strip()
        if debug:
            logger.info(algoritmo)
            logger.info(txt)
            logger.info(digest)
        return digest
    else:
        raise ValueError('Algoritmo deve essere SHA o MD5 (fornito %s)' % algoritmo)
