# -*- coding: utf-8 -*-

from Products.CMFCore.permissions import setDefaultRoles

PROJECTNAME = 'CamComPagamentiOnline'

# Nel caso il tool venga ricreato, permette di inizializzare il prossimo numero di transazione da questo valore
START_TRANSITION_CODES_FROM = 1
# Massimo numero di cifre del numero d'ordine
TRANS_CODE_MAX_LEN = 50

ADD_CONTENT_PERMISSION = PROJECTNAME+': aggiungi pagamento online'
USE_PAGAMENTI_TOOL_PERMISSION = PROJECTNAME+': use tool'

setDefaultRoles(ADD_CONTENT_PERMISSION, ('Manager',))
setDefaultRoles(USE_PAGAMENTI_TOOL_PERMISSION, ('Manager',))

ADD_PERMISSIONS = {
    'PagamentoOnline': ADD_CONTENT_PERMISSION,
}