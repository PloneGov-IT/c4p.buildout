.. contents:: **Table of contents**

Prime Warning
=============

.. Note::
   Mostly of this product source code and user interface **is not** internationalized;
   badly is in italian language. Is probable that if your user/customer is not inside Italy
   you don't find a useful product there.
   
   Is also a port of old Plone 2.0 code to Plone 3+ world. A lot of think can be enhanced.

Introduction
============

This product give you a Plone integration with on-line payment procedure given by different services. These procedures are given by separate plugins that you can install to make this product work (for example cciaa.pagamentionline.setefi).

See the documentation in the *docs* folder of source code for detailed informations. 

It provides a Plone form that ask for some user data, then redirect the user to the 3rd party
online application for perform payment (with credit card access).

.. Note::
   No sensible data like credit card number is given or saved to Plone, leaving this only
   to the dedicate service.

Some other data and some response from the pay service are then saved to Plone as a new content type
"PagamentoOnline" (Online Payment).

Security
--------

This product don't want to leave to Plone site all credit card security issues. It talk to a remote service,
and exchange data with it performing action that make impossible to someone else to intercept the data
sent and modify it.

See documentation in the source for technical informations.

Accessibility
-------------
This product want to usable in Plone italian installation that needs to pass all required of
the `Stanca Act`__

__ http://www.pubbliaccesso.it/normative/DM080705-A-en.htm

How to use
==========

After the configuration (see below) from Plone users must access to the *form_pagamenti_online* form::

    http://myplonehost/form_pagamenti_online

This will give to users (Anonymous users) a way to perform payment, collecting some data (some required,
some other not), kind of service to buy and the price.

Price can be freely filled by users (that maybe concorded it with the site owner earlier) or not visible,
as selectable from a closed set (see below).

After payment (wherever it goes well or wrong) you will find the generated *Pagamento Online* in the
configured folder.

Please **make the folder containing those content types non-readable** by not authorized users.

When the payment is completed (in any case) a notification is sent to ad e-mail address (see below).

Configuration
=============

Configuration depends from data given to you by on-line service.

After installation, go to Plone site root. You will se a new tool with id *camcom_pagamentionline_tool*.
From there you must customize whats follow.

Servizi possibili per pagamenti (available payment types)
---------------------------------------------------------

Type of services you want to see in the form dropdown. Is the most complex option there so we will
explain it later in a dedicate section.

pagamenti_folder_store
----------------------

Absolute traversing path to a Plone folder when content types will be created when users perform payments.

You need to skip the Plone site's id part, like this::

    /root-folder/subfolder/private/folder 

transition_after_creation
-------------------------

A worfklow transition to be applied to all payment, after the user create it. If you need this (optional)
paramenter remember to use there a transition that:

* the Manager is able to perform
* is existing in the worflow initial state

connection_userid
-----------------

Unique identification for the merchant, given by on-line service.

connection_password
-------------------

Unique password set for the merchant userid.

url_post
--------

The remote URL of the service, where the user will put his credit card data.

urlback
-------

A Plone view that will be called if the user press "Annulla" (Cancel) on the on-line payment service or the transaction fails.
Given default show static text to user.

urldone
-------

A Plone view that will be called when the user complete the payment.
Given default show some data of the payment and the final outcome.

email_notification
------------------

An e-mail address that will be used at every completed payment (not if you use the *fixed_imports* option below)

If not provided, the default Plone site e-mail is used.

fixed_imports
-------------

This check must be only used if you don't want that used can fill freely the price related to a kind of service
provided.

In that case you don't need to give only a service description, but also a service price.
Please, read carefully the "Available Payment Types configruation" section to know how.

Available Payment Types configruation
=====================================

The simpler way is to fill this field with a simple set of descriptions::

    Service one
    Service two

You can also provide a reference e-mail for each type of service. In that case *this* e-mail will be used
for notification on new payment instead of the general ones as described abowe::

    Service one|service1@mydomain.com
    Service two|service2@mydomain.com

Configuration with "fixed_imports"
----------------------------------

If you checked the *fixed_imports* option above, you must configure types as::

    Service one|value.cc
    Service two|anothervalue.cc

...or (if you want to provide also dedicate e-mail)::

    Service one|value.cc|service1@mydomain.com
    Service two|anothervalue.cc|service2@mydomain.com

Price strings must be always in the form "value.cc" like "0.05" or "134.00", so always provide the cent part.

Optional e-mail notification, required imports
----------------------------------------------

When using *fixed_imports* you **must** provide always the ``service|price`` version or the
``service|price|email`` version.

Instead, you are free to specify a reference e-mail for some kind of service, and not for other, so this
two configuration are valid::

    Service one|value.cc
    Service two

(without *fixed_imports*)

    Service one|123.00|value.cc
    Service two|45.95

(with *fixed_imports*)

Credits
=======

Developed with the support of:

* `Camera di Commercio di Ferrara`__
  
  .. image:: http://www.fe.camcom.it/cciaa-logo.png/
     :alt: CCIAA Ferrara - logo
  
* `Camera di Commercio di Ravenna`__

All of them supports the `PloneGov initiative`__.

__ http://www.fe.camcom.it/
__ http://www.ra.camcom.it/
__ http://www.plonegov.it/

Authors
=======

This product was developed by RedTurtle Technology team.

.. image:: http://www.redturtle.net/redturtle_banner.png
   :alt: RedTurtle Technology Site
   :target: http://www.redturtle.net/
