# -*- coding: utf-8 -*-

import os
from setuptools import setup, find_packages

version = '2.5.3'

tests_require=['zope.testing', 'Products.PloneTestCase']

setup(name='Products.CamComPagamentiOnline',
      version=version,
      description="Pagamenti on-line tramite procedura CIM",
      long_description=open("README.rst").read() + "\n" +
                       open(os.path.join("docs", "HISTORY.txt")).read(),
      # Get more strings from http://www.python.org/pypi?%3Aaction=list_classifiers
      classifiers=[
        'Framework :: Plone',
        'Framework :: Plone :: 3.3',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: GNU General Public License (GPL)',
        ],
      keywords='cim ccfe cciaa plone pagamenti-online',
      author='RedTurtle Technology',
      author_email='sviluppoplone@redturtle.it',
      url='https://code.redturtle.it/svn/camera_di_commercio_fe/Products.CamComPagamentiOnline/',
      license='GPL',
      packages=find_packages(exclude=['ez_setup']),
      namespace_packages=['Products', ],
      include_package_data=True,
      zip_safe=False,
      install_requires=['setuptools',
                        # -*- Extra requirements: -*-
                        ],
      tests_require=tests_require,
      extras_require=dict(test=tests_require),
      test_suite = 'Products.CamComPagamentiOnline.tests.test_docs.test_suite',
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
