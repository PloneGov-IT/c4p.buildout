# -*- coding: utf-8 -*-
# $Id$
"""Actions portlet package"""

from zope.i18nmessageid import MessageFactory
ActionsPortletMessageFactory = MessageFactory('collective.portlet.actions')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
    return
