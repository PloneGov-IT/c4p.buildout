# -*- coding: utf-8 -*-
from Products.CamComPagamentiOnline import logger

default_profile = 'profile-Products.CamComPagamentiOnline:default'


def to_2300(context):
    """
    """
    logger.info('Upgrading Products.CamComPagamentiOnline to version 2300')
    context.runImportStepFromProfile(default_profile, 'browserlayer')
    context.runImportStepFromProfile(default_profile, 'rolemap')
