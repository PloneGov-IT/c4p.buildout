# -*- coding: utf-8 -*-

from Products.CamComPagamentiOnline import logger

KEYS_TO_ADD = (
             ('getCodTrans',
             'FieldIndex',
             {'indexed_attrs': 'getCodTrans', },
             ),
             ('getCodAut',
             'FieldIndex',
             {'indexed_attrs': 'getCodAut', },
             ),
             ('getEsito',
             'FieldIndex',
             {'indexed_attrs': 'getEsito', },
             ),
             )

def setupVarious(context):

    if context.readDataFile('Products.CamComPagamentiOnline_various.txt') is None:
        return
    portal = context.getSite()
    portal.camcom_pagamentionline_tool.setDefaultProperties()
    addKeyToCatalog(context, portal)

def addKeyToCatalog(context, portal):
    '''
    @summary: takes portal_catalog and adds a key to it
    @param context: context providing portal_catalog 
    '''
    pc = portal.portal_catalog

    indexes = pc.indexes()
    for idx in KEYS_TO_ADD:
        if idx[0] in indexes:
            logger.info("Found the '%s' index in the catalog, nothing changed." % idx[0])
        else:
            pc.addIndex(name=idx[0], type=idx[1], extra=idx[2])
            logger.info("Added '%s' (%s) to the catalog." % (idx[0], idx[1]))




