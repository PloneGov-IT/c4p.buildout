Changelog
=========


1.1.1 (2016-07-12)
------------------

- Fix error handling in ufficio_support_view [cekk]


1.1.0 (2016-04-13)
------------------

- Fix SearchableText indexer for Scheda
  [cekk]


1.0.0 (2016-04-01)
------------------

- Change ufficio_timetable field type and upgrade-step [cekk]


0.1.6 (2016-02-29)
------------------

- Fix portlet ufficio render [cekk]


0.1.5 (2016-01-28)
------------------

- Fix translation [neko]


0.1.4 (2016-01-21)
------------------

- Fix get related items for AT in ufficio_view
  [cekk]


0.1.3 (2016-01-18)
------------------

- Fix get related items for AT in ufficio_helper_view
  [cekk]

- Modificata traduzione (#111)
  [neko]

0.1.2 (2016-01-15)
------------------

- Fix permission check in related objects portlet.
  [cekk]


0.1.1 (2016-01-15)
------------------

- Fix object retrieving in portlets and related items.
  Now expired items are not showed. (#108)
  [cekk]


0.1.0 (2016-01-05)
------------------

- Initial release.
  [daniele-andreotti]
