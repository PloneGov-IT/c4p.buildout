Changelog
=========

0.1.1 (2015-10-14)
------------------

- Add safe_html filter for text configuration
  [cekk]


0.1.0 (2015-09-16)
------------------

- Initial release
