# -*- coding: utf-8 -*-

from zope.interface import Interface


class ICookieConsentLayer(Interface):
    """Marker interface for rer.cookieconsent product layer """
