# -*- coding: utf-8 -*-

from zope.i18nmessageid import MessageFactory

topic_viewMessageFactory = MessageFactory('cciaa.topic_view')

def initialize(context):
    pass

