from collective.editablemenu.browser.interfaces import IEditableMenuSettings
from collective.editablemenu.browser.interfaces import IEditableMenuSettings


class IEditableSecondaryMenuSettings(IEditableMenuSettings):
    """
    Settings for secondary menu
    """


class ISecondaryMenuControlpanelSchema(IEditableMenuSettings):
    """
    Controlpanel for secondary menu
    """
