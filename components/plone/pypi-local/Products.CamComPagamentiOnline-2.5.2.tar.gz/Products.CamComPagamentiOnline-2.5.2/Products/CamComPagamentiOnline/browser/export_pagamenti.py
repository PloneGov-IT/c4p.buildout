# -*- coding: utf-8 -*-
from DateTime import DateTime
from Products.Five import BrowserView
from StringIO import StringIO
from csv import DictWriter
from json import dumps
from plone import api
from plone.memoize.view import memoize


class ExportPagamentiView(BrowserView):
    """
    Extract payment infos and return a csv
    """
    filename = "export_pagamenti"

    @property
    def csv_filename(self):
        ''' Return a filename for this csv
        '''
        return '%s-%s.csv' % (self.filename, DateTime().strftime("%Y%m%d"))

    def setHeader(self, *args):
        '''
        Shorcut for setting headers in the request
        '''
        return self.context.REQUEST.RESPONSE.setHeader(*args)

    def brain2row(self, brain):
        ''' Make a csv row out of a brain
        '''
        obj = brain.getObject()
        return {
            'Nome cognome': obj.getFullname(),
            'Denominazione': obj.getDenom(),
            'Indirizzo': obj.getAddress(),
            'CF/P.Iva': obj.getPiva(),
            'Codice transazione': obj.getCodTrans(),
            'Codice autorizzazione': obj.getCodAut(),
            'Esito': obj.getEsito(),
            'Importo': obj.getImporto(),
            'Email': obj.getEmail(),
            'Servizio': obj.getServizio(),
            'Descrizione servizio': obj.getDescrizioneServizio(),
            'Url': obj.absolute_url(),
        }

    @property
    @memoize
    def brains(self):
        ''' Look up for objects to export under this path
        '''
        cciaa_po_tool = api.portal.get_tool(name='camcom_pagamentionline_tool')
        pagamenti_folder_path = '/'.join(api.portal.get().getPhysicalPath()) + cciaa_po_tool.getProperty('pagamenti_folder_store')
        pagamenti_folder = api.content.get(path=pagamenti_folder_path)
        if not pagamenti_folder:
            return []
        return api.content.find(
            context=pagamenti_folder,
            portal_type="PagamentoOnline"
            )

    def get_csv_rows(self, limit=None):
        ''' Return the csv rows as a dictionary
        '''
        if limit is None:
            brains = self.brains
        else:
            brains = self.brains[:limit]
        return map(self.brain2row, brains)

    @property
    @memoize
    def csv_headers(self):
        '''
        return the headers taken from the fields
        '''
        return [
            'Nome cognome',
            'Denominazione',
            'Indirizzo',
            'CF/P.Iva',
            'Codice transazione',
            'Codice autorizzazione',
            'Esito',
            'Importo',
            'Email',
            'Servizio',
            'Descrizione servizio',
            'Url',
        ]

    def get_csv(self, limit=None, as_text=True):
        ''' Get a csv out of the view brains
        '''
        csv_data = StringIO()
        csv_writer = DictWriter(
            csv_data,
            delimiter=",",
            fieldnames=self.csv_headers)
        csv_writer.writeheader()
        map(csv_writer.writerow, self.get_csv_rows())
        csv_data.seek(0)
        return csv_data.read()

    def __call__(self):
        ''' Return the csv if it exists
        '''
        self.setHeader(
            'Content-Type',
            'text/csv; charset=utf8'
        )
        self.setHeader(
            'Content-Disposition',
            'attachment;filename=%s' % self.csv_filename
        )
        api.portal.show_message(
            message=u'Export dei pagamenti avvenuto correttamente',
            request=self.request)
        return self.get_csv()
