# -*- coding: utf-8 -*-
"""Pagamento on-line effettuato"""
__author__  = 'RedTurtle Technology'

from Products.CMFCore.permissions import View
from Products.CMFCore.permissions import ModifyPortalContent
from Products.CMFCore.utils import getToolByName
from AccessControl import ClassSecurityInfo

from zope.interface import implements
from Products.CamComPagamentiOnline.interfaces import IPagamentoOnline

from Products.Archetypes import atapi
from Products.Archetypes.utils import DisplayList

from Products.CamComPagamentiOnline.config import PROJECTNAME
from Products.ATContentTypes.content.base import registerATCT
from Products.ATContentTypes.content.base import ATCTContent
from Products.ATContentTypes.content.schemata import ATContentTypeSchema
from Products.ATContentTypes.content.schemata import finalizeATCTSchema
from Products.ATContentTypes.lib.historyaware import HistoryAwareMixin

ATCamComPaSchema = ATContentTypeSchema.copy() + atapi.Schema((
      # Dati del richiedente
      atapi.StringField('fullname',
         searchable=True,
         schemata="Dati del richiedente",
         widget=atapi.StringWidget(
            label="Nome e Cognome",
            description="Inserire il nome e cognome della persona che richiede il servizio.",
            size=40,
            visible={'view':'False'}
         ),
      ),
      atapi.StringField('name',
         searchable=True,
         schemata="Dati del richiedente",
         widget=atapi.StringWidget(
            label="Nome",
            description="Inserire il nome della persona che richiede il servizio.",
            size=40,
         ),
      ),
      atapi.StringField('lastname',
         searchable=True,
         schemata="Dati del richiedente",
         widget=atapi.StringWidget(
            label="Cognome",
            description="Inserire il cognome della persona che richiede il servizio.",
            size=40,
         ),
      ),
      atapi.StringField('tel',
         schemata="Dati del richiedente",
         widget=atapi.StringWidget(
            label="Tel./Cell.",
            description="Inserire un recapito telefonico.",
            size=30,
         ),
      ),

      # Dati dell'intestatario della ricevuta o fattura
      atapi.StringField('denom',
         searchable=True,
         required=True,
         schemata="Dati intestatario ricevuta/fattura",
         widget=atapi.StringWidget(
            label="Denominazione",
            description="Inserire il Nome e il Cognome della Persona fisica o la Denominazione dell’Impresa alla quale si intende intestare la Ricevuta o la Fattura.",
            size=60,
         ),
      ),
      atapi.StringField('address',
         searchable=True,
         required=True,
         schemata="Dati intestatario ricevuta/fattura",
         widget=atapi.StringWidget(
            label="Indirizzo",
            description="Inserire l’indirizzo completo di Via, numero civico, CAP, Città, e Provincia.",
            size=60,
         ),
      ),
      atapi.StringField('piva',
         required=True,
         schemata="Dati intestatario ricevuta/fattura",
         widget=atapi.StringWidget(
            label="Cod.Fiscale / P.IVA",
            description="Inserire il codice fiscale e/o la Partita Iva dell’intestatario della ricevuta.",
            size=20,
         ),
      ),

      # Dati del pagamento
      atapi.ComputedField('codTrans',
         schemata="Dati del pagamento",
         expression='context.getCodTrans()',
         widget=atapi.ComputedWidget(
            label="Codice della transazione",
            visible={'view' : 'visible', 'edit':'invisible'},
            description="Codice univoco non modificabile, assegnato all'esecuzione della transazione di questo pagamento.",
         ),
      ),
      atapi.ComputedField('codAut',
         schemata="Dati del pagamento",
         expression='context.getCodAut()',
         widget=atapi.ComputedWidget(
            label="Codice dell'autorizzazione",
            visible={'view' : 'visible', 'edit':'invisible'},
            description="Stringa da 2 a 6 lettere ottenuta dal server di pagamento in risposta alla transazione.",
         ),
      ),
      atapi.ComputedField('esito',
         schemata="Dati del pagamento",
         expression='context.getEsito()',
         widget=atapi.ComputedWidget(
            label="Esito",
            visible={'view' : 'visible', 'edit':'invisible'},
            description="OK per transazione eseguita con successo, KO per transazione fallita.",
         ),
      ),
      atapi.FloatField('importo',
         required=True,
         schemata="Dati del pagamento",
         validators=("isDecimal",),
         widget=atapi.DecimalWidget(
            label="Importo",
            description="Viene considerata la precisione fino a 2 decimali.",
            size=30,
         ),
      ),
      atapi.StringField('email',
         schemata="Dati del pagamento",
         searchable=True,
         validators=("isEmail",),
         widget=atapi.StringWidget(
            label="E-mail",
            description="A questo indirizzo arriveranno le comunicazioni di avvenuto pagamento via carta di credito: verificarne la correttezza.",
            size=30,
         ),
      ),
      atapi.StringField('servizio',
         schemata="Dati del pagamento",
         required=True,
         vocabulary="getServizi",
         enforceVocabulary=True,
         default='',
         widget=atapi.SelectionWidget(
            label="Servizio acquistato",
            description="La descrizione del servizio è obbligatoria, per fornire gli estremi delle istanze o dei soggetti di riferimento",
            format='select',
         ),
      ),
      atapi.TextField('descrizione_servizio',
            schemata="Dati del pagamento",
            default='',
            searchable=True,
            accessor="getDescrizioneServizio",
            mutator="setDescrizioneServizio",
            widget=atapi.TextAreaWidget(
                label="Descrizione del servizio",
                description="La descrizione del servizio è obbligatoria, per fornire gli estremi delle istanze o dei soggetti di riferimento.",
            ),
      ),

    ))

finalizeATCTSchema(ATCamComPaSchema)

ATCamComPaSchema.get('id').schemata = "Generale"
ATCamComPaSchema.get('title').schemata = "Generale"
ATCamComPaSchema.get('relatedItems').schemata = "Generale"
ATCamComPaSchema.get('description').schemata = "Generale"
ATCamComPaSchema.get('description').widget.visible['edit'] = "invisible"
ATCamComPaSchema.get('allowDiscussion').schemata = "Generale"


class PagamentoOnline(ATCTContent, HistoryAwareMixin):
    """Registrazione di un pagamento on-line"""
    implements(IPagamentoOnline)

    schema = ATCamComPaSchema
    meta_type = 'PagamentoOnline'

    security = ClassSecurityInfo()

    def __init__(self, oid, **kwargs):
        ATCTContent.__init__(self, oid, **kwargs)
        self.__codTrans = ''
        self.__codAut = ''
        self.__esito = ''

    security.declareProtected(ModifyPortalContent,'setCodTrans')
    def setCodTrans(self, newCodTrans):
        """Imposta il nuovo codice della transazione solo se non era già stato salvato, e ritorna comunque il codice salvato"""
        if not self.__codTrans:
            self.__codTrans = newCodTrans
        return self.__codTrans

    security.declareProtected(View, 'getCodTrans')
    def getCodTrans(self):
        """Ottiene il codice della transazione di questo pagamento"""
        if not self.__codTrans:
            return "Nessuna transazione associata"
        return self.__codTrans

    security.declareProtected(ModifyPortalContent,'setCodAut')
    def setCodAut(self, newCodAut):
        """Imposta il nuovo messaggio ottenuto dal server"""
        self.__codAut = newCodAut
        return self.__codAut

    security.declareProtected(View, 'getCodAut')
    def getCodAut(self):
        """Ottiene il codice dell'autorizzazione in risposta al pagamento (2-6 caratteri)"""
        if not self.__codAut:
            return "Transazione non eseguita"
        return self.__codAut

    security.declareProtected(ModifyPortalContent,'setEsito')
    def setEsito(self, newEsito):
        """Imposta il nuovo messaggio ottenuto dal server"""
        self.__esito = newEsito
        return self.__esito

    security.declareProtected(View, 'getEsito')
    def getEsito(self):
        """Ottiene il l'esito (OK o KO) della transazione"""
        if not self.__esito:
            return "Transazione non eseguita"
        return self.__esito

    security.declarePrivate('getServizi')
    def getServizi(self):
        """Ottiene i servizi possibili per i pagamenti"""
        servizi = [("", "[Selezionare un servizio]")]
        potool = getToolByName(self, 'camcom_pagamentionline_tool')
        pol_types = potool.getProperty('pol_types')
        [servizi.append((x, x)) for x in pol_types]
        return DisplayList(servizi)

registerATCT(PagamentoOnline, PROJECTNAME)
