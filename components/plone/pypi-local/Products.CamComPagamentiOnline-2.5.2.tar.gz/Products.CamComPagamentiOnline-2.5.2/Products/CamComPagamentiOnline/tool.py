# -*- coding: utf-8 -*-

"""Tool PagamentiOnline per CCIAA - RedTurtle Technology 2006"""

import urllib
# X il codice univoco
from DateTime import DateTime
import thread

# Zope imports
from AccessControl import ClassSecurityInfo
from OFS.SimpleItem import SimpleItem
from Products.PageTemplates.PageTemplateFile import PageTemplateFile
import Globals

# CMF imports
from OFS.PropertyManager import PropertyManager
from Products.CamComPagamentiOnline import config
from Products.CamComPagamentiOnline import logger
from Products.CamComPagamentiOnline.interfaces import IPagamentoOnlineConnection
from Products.CMFCore import permissions
from Products.CMFCore.utils import UniqueObject, getToolByName
from zope.component import getMultiAdapter
from zope.component.interfaces import ComponentLookupError
try:
    # Plone < 4.3
    from zope.app.component.hooks import getSite
except ImportError:
    # Plone >= 4.3
    from zope.component.hooks import getSite


lock = thread.allocate_lock()

PROPERTIES = (('pagamenti_folder_store', '', 'string'),
              ('connection_userid', '', 'string'),
              ('connection_password', '', 'string'),
              ('transition_after_creation', '', 'string'),
              ('url_post', '', 'string'),
              ('urlback', 'po_aborted', 'string'),
              ('urldone', 'po_committed', 'string'),
              ('email_notification', '', 'string'),
              ('fixed_imports', False, 'boolean'),
             )

MAIL_MODEL = """E' stato effettuato un nuovo pagamento:
%(url)s

Esito dell'operazione: %(esito)s

I dati riassuntivi sono:
 * Nome e Cognome: %(fullname)s
 * Codice transazione: %(codTrans)s
 * E-mail: %(email)s
 * Tel./Cell.: %(tel)s
 * Denominazione: %(denom)s
 * Indirizzo: %(address)s
 * Cod.Fiscale / P.IVA: %(piva)s
 * Importo: %(importo)s
 * Servizio acquistato: %(servizio)s
 * Ulteriore descrizione fornita: %(descrizione_servizio)s
"""


class PagamentiOnlineTool(UniqueObject, SimpleItem, PropertyManager):
    """Tool pagamenti online con sistema CIM."""

    plone_tool = 1
    id = "camcom_pagamentionline_tool"
    meta_type = "CCIAA PO Tool"
    security = ClassSecurityInfo()

    manage_options = PropertyManager.manage_options + ({'label': 'Overview', 'action': 'manage_overview'},)

    pol_types = tuple()

    _properties = PropertyManager._properties + ({'id': 'pol_types',
                                                  'type': 'lines',
                                                  'mode': 'rw',
                                                  'label': 'Servizi possibili per pagamenti',
                                                 },
                                                )

    security.declareProtected(permissions.ManagePortal, 'manage_overview')
    manage_overview = PageTemplateFile('www/explainTool', globals(),
                                       __name__='manage_overview')

    def __init__(self):
        self.manage_changeProperties(title='Gestione dei pagamenti on-line')
        self.setDefaultProperties()

        # Generazione codice progressivo
        self.setTransDateCode()
        self.__next_trans_id = config.START_TRANSITION_CODES_FROM

    def setTransDateCode(self):
        '''
        Sets the date used for numord calculation
        '''
        self.__trans_date_code = DateTime().strftime("%Y%m%d")

    security.declareProtected(config.USE_PAGAMENTI_TOOL_PERMISSION, 'setDefaultProperties')
    def setDefaultProperties(self):
        '''
        Adds the properties to the tool at init time
        '''
        for key, value, t in PROPERTIES:
            if not self.hasProperty(key):
                self.manage_addProperty(key, value, t)
                logger.info('Added %s' % key)

    def esegui_po(self, obj):
        """
        """
        portal = getSite()
        try:
            po_view = getMultiAdapter(
                (portal, portal.REQUEST),
                name="po_support_view"
            )
        except ComponentLookupError:
            # there isn't any registered view
            return ""
        url = po_view.generateTransactionUrl(tool=self, item=obj)
        if url:
            obj.reindexObject()
            return url
        else:
            return ""

    security.declareProtected(config.USE_PAGAMENTI_TOOL_PERMISSION, 'getNextTransitionCode')
    def getNextTransitionCode(self):
        """Genera il prossimo codice univoco della transazione
        Codice alfanumerico di almeno 50 caratteri
        """
        lock.acquire()
        # vogliamo che questa parte del numero d'ordine non superi le 6 cifre
        if self.__next_trans_id >= 1000000:
            self.setTransDateCode()
            self.__next_trans_id = 1
        numord = "%s-%s" % (self.__trans_date_code,
                            str(self.__next_trans_id).zfill(6))
        self.__next_trans_id += 1
        lock.release()
        return numord

    security.declareProtected(config.USE_PAGAMENTI_TOOL_PERMISSION, 'getCurrentTransitionNumber')
    def getCurrentTransitionNumber(self):
        """Ottiene il codice univoco che verrà utilizzato al prossio pagamento (senza farlo incrementare)"""
        return self.__next_trans_id

    security.declareProtected(config.USE_PAGAMENTI_TOOL_PERMISSION, 'getCurrentTransitionDateCode')
    def getCurrentTransitionDateCode(self):
        """Ottiene il codice della data di creazione di questo oggetto"""
        return self.__trans_date_code

    security.declarePublic('getPagamentoOnlineByCodeTrans')
    def getPagamentoOnlineByCodeTrans(self, numord):
        """Ottiene un oggetto PagamentoOnline tramite catalogo per un anonimo"""
        catalog = getToolByName(self, 'portal_catalog')
        res = catalog.unrestrictedSearchResults(getCodTrans=numord)
        if res:
            return res[0]
        return None

    security.declarePublic('encodeURL')
    def encodeURL(self, url):
        """Codifica una stringa per il trasporto su Web"""
        return urllib.quote_plus(url)

    def getPayTypes(self):
        """Ottieni i possibili tipi di pagamento"""
        props = self.getProperty('pol_types', [])
        fixed_imports = self.getProperty('fixed_imports')
        results = []
        for x in props:
            if fixed_imports:
                try:
                    l, v = x.split("|")
                except ValueError:
                    l, v, e = x.split("|")
                results.append({'title': "%s - %s€" % (l,v), 'value': l})
            else:
                try:
                    l, e = x.split("|")
                    results.append({'title': l, 'value': l})
                except ValueError:
                    results.append({'title': x, 'value': x})
        return results

    def getPriceFor(self, service):
        """Dato un servizio, ottieni il suo costo"""
        props = self.getProperty('pol_types', [])
        vals = {}
        for x in props:
            try:
                k,v = x.split("|")
            except ValueError:
                k,v,e = x.split("|")
            vals[k] = v
        return vals[service]

    def _getNotificationEmail(self, servizio):
        """Ottiene un indirizzo e-mail legato al tipo di servizio comprato"""
        portal = getToolByName(self, 'portal_url').getPortalObject()
        props = self.getProperty('pol_types', [])
        fixed_imports = self.getProperty('fixed_imports')
        results = {}
        for x in props:
            if fixed_imports:
                try:
                    l, v = x.split("|")
                    e = self.getProperty("email_notification") or portal.getProperty('email_from_address')
                except ValueError:
                    l, v, e = x.split("|")
                results[l] = e
            else:
                try:
                    l, e = x.split("|")
                    results[l] = e
                except ValueError:
                    results[x] = self.getProperty("email_notification") or portal.getProperty('email_from_address')
        return results.get(servizio, self.getProperty("email_notification") or portal.getProperty('email_from_address'))

    security.declarePublic('log_error')
    def log_error(self, msg):
        logger.error(msg)

    security.declarePublic('notify')
    def notify(self, payment):
        """
        send a mail notification
        """
        mail_host = getToolByName(self, 'MailHost')
        portal = getToolByName(self, 'portal_url').getPortalObject()
        message = MAIL_MODEL % {'url': payment.absolute_url(),
                                'esito': payment.getEsito(),
                                'fullname': payment.getFullname(),
                                'codTrans': payment.getCodTrans(),
                                'email': payment.getEmail(),
                                'importo': payment.getImporto(),
                                'servizio': payment.getServizio(),
                                'descrizione_servizio': payment.getDescrizioneServizio(),
                                'tel': payment.getTel(),
                                'address': payment.getAddress(),
                                'denom': payment.getDenom(),
                                'piva': payment.getPiva(),
                                }
        mail_host.secureSend(message,
                             mto=self._getNotificationEmail(payment.getServizio()),
                             mfrom=self.getProperty("email_notification") or portal.getProperty('email_from_address'),
                             subject='Notifica di nuovo pagamento (%s)' % payment.getCodTrans(),
                             charset='utf-8',
                             )


Globals.InitializeClass(PagamentiOnlineTool)
