## Script (Python) "save_pagamenti_online"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=Salvataggio pagamenti online utente
##
from Products.CMFCore.utils import getToolByName

plone_utils = getToolByName(context, 'plone_utils')

request = context.REQUEST
response = request.RESPONSE
cciaa_po_tool = getToolByName(container, 'camcom_pagamentionline_tool', None)
if not cciaa_po_tool:
    plone_utils.addPortalMessage(u'Tool dei pagamenti non trovato', type='error')
    # Non c'è il tool installato...
    response.redirect(context.absolute_url_path())
    return

portal = getToolByName(container, 'portal_url').getPortalObject()
wtool = getToolByName(container, 'portal_workflow')
pagamenti_folder = '/'.join(portal.getPhysicalPath()) + cciaa_po_tool.getProperty('pagamenti_folder_store')

refPagamentiFolder = context.restrictedTraverse(pagamenti_folder, default=None)

if not refPagamentiFolder:
    # Controllo se c'è il folder per il salvataggio dei pagamenti online
    plone_utils.addPortalMessage(u'Cartella %s non trovata' % pagamenti_folder, type='error')
    response.redirect(context.absolute_url_path())
    return

newr = request.form.copy()
if cciaa_po_tool.getProperty('fixed_imports') and request.get('servizio')!='Altro...':
    newr['importo'] = cciaa_po_tool.getPriceFor(request.get('servizio'))
else:
    newr['importo'] = "%s.%s" % (request.get('importo'), request.get('importo_dec'))

fullname = '%s %s' % (request.get('name', ''),request.get('lastname', ''))

da = fullname or request.get('denom', '')
newr['title'] = "Pagamento di %s€ per '%s' da %s" % (newr.get('importo'),
                                                     request['servizio'],
                                                     da)

descrizione_servizio = request.get('descrizione_servizio')
if len(descrizione_servizio) > 150:
    descrizione_servizio = descrizione_servizio[:147] + '...'

newr['description'] = descrizione_servizio

utool = context.plone_utils
newId = refPagamentiFolder.generateUniqueId(utool.normalizeString(da))

refPagamentiFolder.invokeFactory(id=newId, type_name='PagamentoOnline')

newDoc = getattr(refPagamentiFolder, newId)
newDoc.edit(**newr)

if cciaa_po_tool.getProperty('transition_after_creation'):
    wtool.doActionFor(newDoc, cciaa_po_tool.getProperty('transition_after_creation'))

newDoc.reindexObject()

url_pagamento = cciaa_po_tool.esegui_po(newDoc)
if not url_pagamento:
    plone_utils.addPortalMessage(u'Si sono verificati problemi nel contattare il server della banca.', type='error')
    response.redirect(context.absolute_url_path())
    return
response.redirect(url_pagamento)
