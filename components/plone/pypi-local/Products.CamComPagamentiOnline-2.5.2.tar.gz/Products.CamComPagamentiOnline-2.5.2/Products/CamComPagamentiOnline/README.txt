Documentazione
==============

This is a full-blown functional test. The emphasis here is on testing what
the user may input and see, and the system is largely tested as a black box.
We use PloneTestCase to set up this test as well, so we have a full Plone site
to play with. We *can* inspect the state of the portal, e.g. using 
self.portal and self.folder, but it is often frowned upon since you are not
treating the system as a black box. Also, if you, for example, log in or set
roles using calls like self.setRoles(), these are not reflected in the test
browser, which runs as a separate session.

Being a doctest, we can tell a story here.

First, we must perform some setup. We use the testbrowser that is shipped
with Five, as this provides proper Zope 2 integration. Most of the 
documentation, though, is in the underlying zope.testbrower package.

>>> from Products.Five.testbrowser import Browser
>>> browser = Browser()
>>> portal_url = self.portal.absolute_url()

The following is useful when writing and debugging testbrowser tests. It lets
us see all error messages in the error_log.

>>> self.portal.error_log._ignored_exceptions = ()

With that in place, we can go to the portal front page and log in. We will
do this using the default user from PloneTestCase:

>>> from Products.PloneTestCase.setup import portal_owner, default_password
>>> browser.open(portal_url)

We have the login portlet, so let's use that.

>>> browser.getControl(name='__ac_name').value = portal_owner
>>> browser.getControl(name='__ac_password').value = default_password
>>> browser.getControl(name='submit').click()

Here, we set the value of the fields on the login form and then simulate a
submit click.

We then test that we are still on the portal front page:

>>> browser.url == portal_url
    True

And we ensure that we get the friendly logged-in message:

>>> "You are now logged in" in browser.contents
    True

We should have a get_mac function:

>>> from Products.CamComPagamentiOnline.utilities import get_mac
>>> codTrans="testCILME534"
>>> importo="1"
>>> chiave = "esempiodicalcolomac"
>>> mac = get_mac(codTrans, importo, chiave)
>>> mac
'ZjRkZDdkNWNmYThlZmYyNTJiN2U1ZmI2MDJlNjM5NDI%3D'

Now new API:

>>> codTrans="testCILME534"
>>> importo="1"
>>> chiave = "esempiodicalcolomac"
>>> mac = get_mac(codTrans, importo, chiave, algoritmo='sha')
>>> mac
'992e40c00b79ad1a6e4a5a8c61e776e696796a79'


PARAMETRI DA UTILIZZARE PER I TEST (vecchie specifiche)
-------------------------------------------------------

- URL di collegamento = https://ecommerce.cim-italia.it/ecomm/DispatcherServlet
- IDNEGOZIO = payment_test_migrazione
- La stringa segreta da utilizzare per il calcolo del parametro Mac è uguale a 
  "esempiodicalcolomac" (senza i doppi apici di inizio/fine)

I dati della Carta di Credito di test per il pagamento alla pagina di cassa sono:
- Nr. Carta 5255999999999992
- 04/11, o comunque superiore alla data odierna
- Nr. di sicurezza(Cvv2) deve essere di 3 cifre, a scelta Nome e Cognome a scelta


INFORMAZIONI IMPORTANTI
~~~~~~~~~~~~~~~~~~~~~~~

Occorre verificare se i nostri parametri rispettano queste specifiche:

- NUMORD deve essere di massimo 30 caratteri
- Il calcolo del mac da noi adottato è riferito alla modalità SHA1 e senza options
- LINGUA, per avere la pagina inglese il valore deve essere “ENG” non “EN”
- L’esito viene gestito con valore “OK” o “KO” 

