"""Main product initializer
"""

import logging

from zope.i18nmessageid import MessageFactory
from Products.CamComPagamentiOnline import config

from Products.Archetypes import atapi
from Products.CMFCore import utils

logger = logging.getLogger('CamComPagamentiOnline')
CamComPagamentiOnlineMessageFactory = MessageFactory('Products.CamComPagamentiOnline')


def initialize(context):
    """Initializer called when used as a Zope 2 product.

    This is referenced from configure.zcml. Regstrations as a "Zope 2 product"
    is necessary for GenericSetup profiles to work, for example.

    Here, we call the Archetypes machinery to register our content types
    with Zope and the CMF.
    """

    import content
    # damn pyflakes pre-commit-hook
    content
    from Products.CamComPagamentiOnline import tool

    content_types, constructors, ftis = atapi.process_types(
        atapi.listTypes(config.PROJECTNAME),
        config.PROJECTNAME)

    for atype, constructor in zip(content_types, constructors):
        utils.ContentInit('%s: %s' % (config.PROJECTNAME, atype.portal_type),
            content_types      = (atype,),
            permission         = config.ADD_PERMISSIONS[atype.portal_type],
            extra_constructors = (constructor,),
            ).initialize(context)
    
    # Register tools and content
    utils.ToolInit("%s Tool" % config.PROJECTNAME
                   , tools=(tool.PagamentiOnlineTool,)
                   , icon='skins/cc_pagamenti_online/cciaa_tool_icon.gif'
                   ).initialize( context )

