Changelog
=========

0.1.3 (2017-07-03)
------------------

- plone5 compatibility [mamico]
- corrected typo in LC_MESSAGES for the italian language [arsenico13]


0.1.2 (2015-10-16)
------------------

- cookieconsent cookie now expires in 10 years
  [cekk]


0.1.1 (2015-10-14)
------------------

- Add safe_html filter for text configuration
  [cekk]


0.1.0 (2015-09-16)
------------------

- Initial release
