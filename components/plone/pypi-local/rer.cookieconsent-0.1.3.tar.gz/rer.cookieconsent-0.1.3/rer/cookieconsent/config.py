# -*- coding: utf-8 -*-

COOKIECONSENT_NAME = "cookieconsent"

# Add item to this list to prevent subscriber to send opt-out cookies
# Use it for internal domain (or subdomain) where you don't want to use any opt-out
# Example: DOMAIN_WHITELIST = ['backend.foobar.com', '.bazqux.com']
DOMAIN_WHITELIST = []